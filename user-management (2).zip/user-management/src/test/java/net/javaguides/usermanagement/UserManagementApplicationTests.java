package net.javaguides.usermanagement;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.javaguides.usermanagement.entity.User;
import net.javaguides.usermanagement.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.BDDMockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
class UserManagementApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockitoBean
	private UserService userService;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	void contextLoads() {
	}

	@Test
	public void givenUserObject_whenCreateUser_thenReturnSavedUser() throws Exception{

		// given - precondition or setup
		User user = User.builder()
				.firstName("Ramesh")
				.lastName("Fadatare")
				.email("ramesh@gmail.com")
				.build();
		given(userService.createUser(any(User.class)))
				.willAnswer((invocation)-> invocation.getArgument(0));

		// when - action or behaviour that we are going test
		ResultActions response = mockMvc.perform(post("/api/users")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(user)));

		// then - verify the result or output using assert statements
		response.andDo(print()).
				andExpect(status().isOk())
				.andExpect(jsonPath("$.firstName",
						is(user.getFirstName())))
				.andExpect(jsonPath("$.lastName",
						is(user.getLastName())))
				.andExpect(jsonPath("$.email",
						is(user.getEmail())));

	}


	// JUnit test for Get All users REST API
	@Test
	public void givenListOfUsers_whenGetAllUsers_thenReturnUsersList() throws Exception{
		// given - precondition or setup
		List<User> listOfUsers = new ArrayList<User>();
		listOfUsers.add(User.builder().firstName("Ramesh").lastName("Fadatare").email("ramesh@gmail.com").build());
		listOfUsers.add(User.builder().firstName("Tony").lastName("Stark").email("tony@gmail.com").build());
		given(userService.getAllUsers()).willReturn(listOfUsers);

		// when -  action or the behaviour that we are going test
		ResultActions response = mockMvc.perform(get("/api/users"));

		// then - verify the output
		response.andExpect(status().isOk())
				.andDo(print())
				.andExpect(jsonPath("$.size()",
						is(listOfUsers.size())));

	}


	// positive scenario - valid user id
	// JUnit test for GET user by id REST API
	@Test
	public void givenUserId_whenGetUserById_thenReturnUserObject() throws Exception{
		// given - precondition or setup
		long userId = 1L;
		User user = User.builder()
				.firstName("Ramesh")
				.lastName("Fadatare")
				.email("ramesh@gmail.com")
				.build();
		given(userService.getUserById(userId)).willReturn(Optional.of(user));

		// when -  action or the behaviour that we are going test
		ResultActions response = mockMvc.perform(get("/api/users/{id}", userId));

		// then - verify the output
		response.andExpect(status().isOk())
				.andDo(print())
				.andExpect(jsonPath("$.firstName", is(user.getFirstName())))
				.andExpect(jsonPath("$.lastName", is(user.getLastName())))
				.andExpect(jsonPath("$.email", is(user.getEmail())));

	}

	// negative scenario - valid user id
	// JUnit test for GET user by id REST API
	@Test
	public void givenInvalidUserId_whenGetUserById_thenReturnEmpty() throws Exception{
		// given - precondition or setup
		long userId = 1L;
		User user = User.builder()
				.firstName("Ramesh")
				.lastName("Fadatare")
				.email("ramesh@gmail.com")
				.build();
		given(userService.getUserById(userId)).willReturn(Optional.empty());

		// when -  action or the behaviour that we are going test
		ResultActions response = mockMvc.perform(get("/api/users/{id}", userId));

		// then - verify the output
		response.andExpect(status().isOk())
				.andDo(print());

	}

	// JUnit test for update user REST API - positive scenario
	@Test
	public void givenUpdatedUser_whenUpdateUser_thenReturnUpdateUserObject() throws Exception{
		// given - precondition or setup
		long userId = 1L;
		User savedUser = User.builder()
				.firstName("Ramesh")
				.lastName("Fadatare")
				.email("ramesh@gmail.com")
				.build();

		User updatedUser = User.builder()
				.firstName("Ram")
				.lastName("Jadhav")
				.email("ram@gmail.com")
				.build();
		given(userService.getUserById(userId)).willReturn(Optional.of(savedUser));
		given(userService.updateUser(any(User.class)))
				.willAnswer((invocation)-> invocation.getArgument(0));

		// when -  action or the behaviour that we are going test
		ResultActions response = mockMvc.perform(put("/api/users/{id}", userId)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(updatedUser)));


		// then - verify the output
		response.andExpect(status().isOk())
				.andDo(print())
				.andExpect(jsonPath("$.firstName", is(updatedUser.getFirstName())))
				.andExpect(jsonPath("$.lastName", is(updatedUser.getLastName())))
				.andExpect(jsonPath("$.email", is(updatedUser.getEmail())));
	}

	// JUnit test for update user REST API - negative scenario
	@Test
	public void givenUpdatedUser_whenUpdateUser_thenReturn404() throws Exception{
		// given - precondition or setup
		long userId = 1L;
		User savedUser = User.builder()
				.firstName("Ramesh")
				.lastName("Fadatare")
				.email("ramesh@gmail.com")
				.build();

		User updatedUser = User.builder()
				.firstName("Ram")
				.lastName("Jadhav")
				.email("ram@gmail.com")
				.build();
		given(userService.getUserById(userId)).willReturn(Optional.empty());
		given(userService.updateUser(any(User.class)))
				.willAnswer((invocation)-> invocation.getArgument(0));

		// when -  action or the behaviour that we are going test
		ResultActions response = mockMvc.perform(put("/api/users/{id}", userId)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(updatedUser)));

		// then - verify the output
		response.andExpect(status().is(200))
				.andDo(print());
	}

	// JUnit test for delete employee REST API
	@Test
	public void givenEmployeeId_whenDeleteEmployee_thenReturn200() throws Exception{
		// given - precondition or setup
		long employeeId = 1L;
		willDoNothing().given(userService).deleteUser(employeeId);

		// when -  action or the behaviour that we are going test
		ResultActions response = mockMvc.perform(delete("/api/users/{id}", employeeId));

		// then - verify the output
		response.andExpect(status().is(204))
				.andDo(print());
	}
}



